import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np

# Import data
df = pd.read_csv('medical_examination.csv',header=0)

#df['bmi']=df['weight']/((df['height']/100)**2)
df['overweight']=np.where(df['weight']/((df['height']/100)**2)>25, 1, 0) #overweight col

# Normalize data by making 0 always good and 1 always bad.
df['cholesterol']=np.where(df['cholesterol']>1 , 1, 0)
df['gluc']=np.where(df['gluc']>1 , 1, 0)


df = df[(df['height'] >= df['height'].quantile(0.025)) & (df['height']<= df['height'].quantile(0.975))]
#df = df[df.height >= df['height'].quantile(0.025)] #also works
df = df[(df['weight'] >= df['weight'].quantile(0.025)) & (df['weight']<= df['weight'].quantile(0.975))] #cleaning data
df = df[df['ap_lo']<=df['ap_hi']]

# Draw Categorical Plot
def draw_cat_plot():
    # Create DataFrame for cat plot using `pd.melt` using just the values from 'cholesterol', 'gluc', 'smoke', 'alco', 'active', and 'overweight'.
    df_cat = df.melt(id_vars=['cardio'],value_vars=['cholesterol', 'gluc', 'smoke', 'alco', 'active','overweight'])



    # Group and reformat the data to split it by 'cardio'. Show the counts of each feature. You will have to rename one of the collumns for the catplot to work correctly.
    fig = sns.catplot(kind='count',col='cardio', x='variable', hue = 'value', data=df_cat, order=['active','alco','cholesterol','gluc','overweight','smoke'])

    # Draw the catplot with 'sns.catplot()'
    # Do not modify the next two lines
    fig.savefig('catplot.png')
    return fig


# Draw Heat Map
def draw_heat_map():
    # Clean the data

    df_heat = df.corr()

    # Calculate the correlation matrix
    #corr = None

    # Generate a mask for the upper triangle
    mask_ut=np.triu(np.ones(df_heat.shape)).astype(np.bool)
    plt.figure(figsize=(10, 10))

    



    # Set up the matplotlib figure
    fig, ax =plt.subplots(figsize=(28,18))

    # Draw the heatmap with 'sns.heatmap()'
    sns.heatmap(data=df_heat,mask=mask_ut,annot=True, fmt='.1f', square=True)


    # Do not modify the next two lines
    fig.savefig('heatmap.png')
    return fig
