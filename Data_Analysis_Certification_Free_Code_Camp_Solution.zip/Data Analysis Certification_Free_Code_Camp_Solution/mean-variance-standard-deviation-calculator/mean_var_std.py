import numpy as np

def calculate(list):
  if len(list) != 9:
    raise ValueError('"List must contain nine numbers." ')
  
  calculations = {}
  mat = np.array([list[0:3],list[3:6],list[6:]])
  axis1=[]
  axis2=[]
  for x in range(3):
    axis1.append(mat[:,x])
    axis2.append(mat[x,:]) 

  calculations['mean']=[[axis1[0].mean(),axis1[1].mean(),axis1[2].mean()],[axis2[0].mean(),axis2[1].mean(),axis2[2].mean()], np.mean(list)]

  calculations['variance']=[[axis1[0].var(),axis1[1].var(),axis1[2].var()],[axis2[0].var(),axis2[1].var(),axis2[2].var()], np.var(list)]
  
  calculations['standard deviation']=[[axis1[0].std(),axis1[1].std(),axis1[2].std()],[axis2[0].std(),axis2[1].std(),axis2[2].std()], np.std(list)]

  calculations['max']=[[axis1[0].max(),axis1[1].max(),axis1[2].max()],[axis2[0].max(),axis2[1].max(),axis2[2].max()], np.max(list)]

  calculations['min']=[[axis1[0].min(),axis1[1].min(),axis1[2].min()],[axis2[0].min(),axis2[1].min(),axis2[2].min()], np.min(list)]

  calculations['sum']=[[axis1[0].sum(),axis1[1].sum(),axis1[2].sum()],[axis2[0].sum(),axis2[1].sum(),axis2[2].sum()], np.sum(list)]
  #for x in range(3):
   # axis1.append(mat[:,x].mean())
    #axis2.append(mat[x,:].mean())
  #calculations['mean']=[axis1,axis2, np.mean(list)]





  return calculations